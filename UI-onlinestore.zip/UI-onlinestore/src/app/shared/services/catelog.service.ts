import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Catelog } from '../models/Catelog';
import { Observable } from "rxjs";
import { CatelogCategory } from '../models/CatelogCategory';
import { Product } from '../models/product';
import { CatelogProduct } from '../models/CatelogProduct';

@Injectable()
export class CatelogService {

    private catelogServiceURL = "http://localhost:8081/store/catelog/catelogList/";
    private catelogCatogoryServiceURL = "http://localhost:8081/store/catelog/getcatelogCategoryList/";
    private catelogProductsServiceURL = "http://localhost:8081/store/catelog/getcatelogCategoryList/";

    constructor(private httpClient: HttpClient) {
    }

    getCatelog(): Observable<Catelog[]> {
        return this.httpClient.get<Catelog[]>(this.catelogServiceURL);
    }

    getCatelogCategory(catelogRefId): Observable<CatelogCategory[]> {
        return this.httpClient.get<CatelogCategory[]>(this.catelogCatogoryServiceURL + catelogRefId);
    }

    getCatelogProducts(catelogRefId): Observable<CatelogProduct[]> {
        return this.httpClient.get<CatelogProduct[]>(this.catelogProductsServiceURL + catelogRefId);
    }

}