import { Injectable } from "@angular/core";
import { AngularFireDatabase, AngularFireList } from "@angular/fire/database";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import * as moment from "moment";
import { User } from "../models/user";
import { WSUser } from '../models/WSUser';
import { WSLoginDetails } from 'src/app/shared/models/WSLoginDetails';

@Injectable()
export class UserService {
  selectedUser: User = new User();
  users: AngularFireList<User>;

  private userServiceURL = "http://localhost:8083/store/user/createUser";
  private userServiceLoginURL = "http://localhost:8083/store/login/validate";

  location = {
    lat: null,
    lon: null,
  };

  constructor(private db: AngularFireDatabase, private httpClient: HttpClient) {
    this.getUsers();
  }

  getUsers() {
    this.users = this.db.list("clients");
    return this.users;
  }

  getUserById(id: string) { }

  createNewUser(wsUser: WSUser): Observable<WSUser> {
    const headers = { 'content-type': 'application/json' };
    wsUser.userStatus = "ACTIVE";
    wsUser.roleIds = [2];
    const body = JSON.stringify(wsUser);
    console.log(body);
    return this.httpClient.post<WSUser>(this.userServiceURL, body, { 'headers': headers });
  }

  signInWithUsername(wsLoginDetails: WSLoginDetails): Observable<WSLoginDetails> {
    const headers = { 'content-type': 'application/json' };
    const body = JSON.stringify(wsLoginDetails);
    console.log(body);
    return this.httpClient.post<WSLoginDetails>(this.userServiceLoginURL, body, { 'headers': headers }).pipe(catchError(this.handleError));
  }

  handleError(error) {
   
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }

  createUser(data: any) {
    const updatedData = {
      ...data,
      location: this.location,
      createdOn: moment(new Date()).format("X"),
      isAdmin: false,
    };
    this.users.push(updatedData);
  }

  isAdmin(emailId: string) {
    return this.db.list("clients", (ref) =>
      ref.orderByChild("email").equalTo(emailId)
    );
  }

  updateUser(user: User) {
    this.users.update(user.$key, user);
  }

  setLocation(lat: any, lon: any) {
    this.location = { lat, lon };
  }
}
