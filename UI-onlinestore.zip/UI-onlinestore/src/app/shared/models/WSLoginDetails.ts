export class WSLoginDetails {
    userName: string;
    password: string;
}