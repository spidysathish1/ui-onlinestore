import { CatelogCategory } from './CatelogCategory';

export class Catelog {
    $key: string;
    catelogId: number;
    catelogName: string;
    catelogDesc: string;
    catelogCategory: CatelogCategory[];
    
}
