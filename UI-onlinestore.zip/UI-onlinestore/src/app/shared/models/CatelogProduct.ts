export class CatelogProduct {
    productId: number;
    productName: string;
    productDesc: string;
    productPrice: number;
    isAvailable: boolean;
    instockCount: number;
    catelogRefId: number;
  }
  