export class WSUser {
    firstName: string;
    lastName: string;
    userName: string;
    emailId; string;
    password: string;
    userStatus: string;
    roleIds: Array<number>;
}