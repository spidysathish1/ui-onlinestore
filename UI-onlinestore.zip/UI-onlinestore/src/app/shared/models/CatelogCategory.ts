export class CatelogCategory{
    categoryId: number;
    categoryName: string;
    categoryDesc: string;
    isActive: boolean;
}
