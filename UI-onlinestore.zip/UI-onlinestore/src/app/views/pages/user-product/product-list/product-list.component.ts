import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { CatelogCategory } from 'src/app/shared/models/CatelogCategory';
import { CatelogProduct } from 'src/app/shared/models/CatelogProduct';
import { CatelogService } from 'src/app/shared/services/catelog.service';
import { ToastrService } from 'src/app/shared/services/toastr.service';

@Component({
  selector: "app-products-list",
  templateUrl: "./product-list.component.html",
  styleUrls: ["./product-list.component.scss"],
})
export class ProductsCatelogListComponent implements OnInit {
  private sub: any;
  // Not Found Message
  messageTitle = "No Products Found";
  messageDescription = "Please, choose other category";
  catelog: CatelogCategory;
  catelogProductsList: CatelogProduct[];
  loading = false;
  page = 1;
  catelogResponse: Object[];
  catelognewResponse: any;

  constructor(private route: ActivatedRoute,
    public catelogService: CatelogService,
    private toastrService: ToastrService
  ) {
    this.catelog = new CatelogCategory();
  }

  ngOnInit() {
    this.sub = this.route.params.subscribe((params) => {
      const id = params.id; // (+) converts string 'id' to a number
      this.getAllProductsForCategory(id);
    });
  }

  getAllProductsForCategory(catelogRefId) {
    this.loading = true;
    this.catelogService.getCatelogProducts(catelogRefId).subscribe((catelogCategory) => {
      this.loading = false;
      alert(catelogCategory);
      this.catelogProductsList = [];
      this.catelogProductsList = catelogCategory;
    },
      (err) => {
        this.toastrService.error("Error while fetching Products", err);
      }
    );
  }
}
