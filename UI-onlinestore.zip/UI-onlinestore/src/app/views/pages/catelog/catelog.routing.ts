import { Routes } from "@angular/router";
import { IndexComponent } from "../../base/index/index.component";
import { ProductsCatelogListComponent } from '../user-product/product-list/product-list.component';
import { CatelogCategoryComponent } from './catelog-category/catelog-category.component';
import { CatelogListComponent } from './catelog-list/catelog-list.component';

export const CatelogRoutes: Routes = [
  {
    path: "catelog",
    children: [
      {
        path: "",
        component: IndexComponent,
      },
      {
        path: "all-catelogs",
        component: CatelogListComponent,
      },
      {
        path: "all-catelog-products/:id",
        component: ProductsCatelogListComponent,
      },
      {
        path: "catelogCategory/:id",
        component: CatelogCategoryComponent,
      },

    ],
  },
];
