import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { CatelogCategory } from 'src/app/shared/models/CatelogCategory';
import { CatelogService } from 'src/app/shared/services/catelog.service';
import { ToastrService } from 'src/app/shared/services/toastr.service';

@Component({
  selector: "app-catelog-category",
  templateUrl: "./catelog-category.component.html",
  styleUrls: ["./catelog-category.component.scss"],
})
export class CatelogCategoryComponent implements OnInit {
  private sub: any;
  // Not Found Message
  messageTitle = "No Products Found";
  messageDescription = "Please, choose other category";
  catelog: CatelogCategory;
  catelogCategoryList: CatelogCategory[];
  loading = false;
  page = 1;
  catelogResponse: Object[];
  catelognewResponse: any;

  constructor(private route: ActivatedRoute,
    public catelogService: CatelogService,
    private toastrService: ToastrService
  ) {
    this.catelog = new CatelogCategory();
  }

  ngOnInit() {
    this.sub = this.route.params.subscribe((params) => {
      const id = params.id; // (+) converts string 'id' to a number
      this.getAllCatelogCategory(id);
    });
  }

  getAllCatelogCategory(catelogRefId) {
    this.loading = true;
    this.catelogService.getCatelogCategory(catelogRefId).subscribe((catelogCategory) => {
      this.loading = false;
      this.catelogCategoryList = [];
      this.catelogCategoryList = catelogCategory;
    },
      (err) => {
        this.toastrService.error("Error while fetching Products", err);
      }
    );
  }
}
