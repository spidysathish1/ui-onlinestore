// Core Dependencies
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { CatelogRoutes } from './catelog.routing';
import { CatelogListComponent } from "./catelog-list/catelog-list.component";
import { SharedModule } from 'src/app/shared/shared.module';
import { CatelogCategoryComponent } from './catelog-category/catelog-category.component';
import { ProductsCatelogListComponent } from '../user-product/product-list/product-list.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(CatelogRoutes),
    SharedModule
  ],
  declarations: [
    CatelogListComponent,
    CatelogCategoryComponent,
    ProductsCatelogListComponent,
  ],
  exports: [],
})
export class CatelogModule { }
