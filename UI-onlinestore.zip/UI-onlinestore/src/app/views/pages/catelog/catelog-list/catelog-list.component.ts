import { Component, OnInit } from "@angular/core";
import { Catelog } from 'src/app/shared/models/Catelog';
import { CatelogService } from 'src/app/shared/services/catelog.service';
import { ToastrService } from 'src/app/shared/services/toastr.service';

@Component({
  selector: "app-catelog-list",
  templateUrl: "./catelog-list.component.html",
  styleUrls: ["./catelog-list.component.scss"],
})
export class CatelogListComponent implements OnInit {
  catelogList: Catelog[];
  loading = false;
  page = 1;
  catelogResponse: Object[];
  catelognewResponse: any;

  constructor(
    public catelogService: CatelogService,
    private toastrService: ToastrService
  ) { }

  ngOnInit() {
    this.getAllCatelogs();
  }

  getAllCatelogs() {
    this.loading = true;
    this.catelogService.getCatelog().subscribe((catelog) => {
      this.loading = false;
      this.catelogList = [];
      this.catelogList = catelog;
    },
      (err) => {
        this.toastrService.error("Error while fetching Products", err);
      }
    );
  }
}
