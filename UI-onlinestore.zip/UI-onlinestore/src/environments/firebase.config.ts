export const FireBaseConfig = {
  apiKey: "AIzaSyDpQzDBS8hJzoiu0rmysBbz3nq-mmHy2RQ",
  authDomain: "onlinestore-8fb7a.firebaseapp.com",
  databaseURL: "https://onlinestore-8fb7a.firebaseio.com",
  projectId: "onlinestore-8fb7a",
  storageBucket: "onlinestore-8fb7a.appspot.com",
  messagingSenderId: "435393352233",
};
